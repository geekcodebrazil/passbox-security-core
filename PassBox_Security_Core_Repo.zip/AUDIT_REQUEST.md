Open invitation for independent security audit.
