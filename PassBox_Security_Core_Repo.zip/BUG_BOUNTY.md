Community bug bounty program (light).
