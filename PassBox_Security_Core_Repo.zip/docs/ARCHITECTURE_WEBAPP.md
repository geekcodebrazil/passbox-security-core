WebApp Zero-Knowledge architecture.
