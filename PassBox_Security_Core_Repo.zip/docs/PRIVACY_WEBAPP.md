Privacy policy for WebApp.
