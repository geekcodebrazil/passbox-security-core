Threat model for PassBox WebApp.
