High level security overview.
